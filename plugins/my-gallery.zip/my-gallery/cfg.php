<?php
$my_gallery_language="en";
$my_gallery_selected_dir="805ed3e038b8fd8";
$my_gallery_selected_name="My gallery";
$my_gallery_default_thumbnails_size="240";
$my_gallery_default_images_size="1024";
$my_gallery_default_max_file_size="7";
?>